// const initialState = {
//   isVisible: false,
//   title: "",
//   show: null,
// };

// const popUpReducer = (state = initialState, action) => {
//   console.log(action);
//   switch (action.type) {
//     case "SHOW_POPUP":
//       return {
//         ...state,
//         isVisible: true,
//       };
//     case "HIDE_POPUP":
//       return { ...state };
//     default:
//       return { ...state };
//   }
// };

// export default popUpReducer;
