import React from "react";
import CardWithTitle from "../../../../../components/cards/cardWithTitle/cardWithTitle";
import Buttons from "../../../../../components/buttons/button";
import RecentCheckIn from "../../../../../components/cards/Profilecard/recentCheckIn";
import checkInData from "../../../../../utils/checkInData";
import { InputTextarea } from "primereact/inputtextarea";
import { useState } from "react";
import validation from "../../../../../utils/Validation";

const Notes = ({ setData, data, createEmployee }) => {
  const [showNotes, setActiveNotes] = useState(false);
  const [noteValue, setNoteValue] = useState({ note: "" });
  const { notesValidation } = validation();
  const [errors, setErrors] = useState({});

  const onClickActiveNotes = () => {
    setActiveNotes((prev) => !prev);
  };

  const addNote = () => {
    let validate = notesValidation(noteValue);
    if (Object.keys(validate).length) {
      return setErrors(validate);
    };

    setData(() => {
      return {
        ...data,
        notes: [
          ...data.notes,
          {
            ...noteValue,
          },
        ],
      };
    });
    setNoteValue({ note: "" });
    setActiveNotes(false);
    return setErrors({});
  };

  const showTableNotes = () => {
    return (
      <>
        <div>
          <div>
            <CardWithTitle
              title="Taken By"
              title2="Date/Time"
              title3="Notes"
              title1className="w-3"
              title2className="w-3"
              title3className="w-4"
            >
              {!data.notes.length ? (
                <div
                  style={{ height: "250px" }}
                  className="p-3 flex justify-content-center align-items-center"
                >
                  <div className="font-semibold">None Found</div>
                </div>
              ) : (
                data.notes.map((item) => {
                  return (
                    <>
                      <div
                        style={{ height: "auto" }}
                        className="p-3 flex justify-content-between"
                      >
                        <div className="font-semibold col-4">
                          <span>{item.createdBy}</span>
                        </div>
                        <div className="font-semibold col-4 ">
                          <span>{`${new Date(
                            item.createdAt
                          ).toLocaleDateString()} ${new Date(
                            item.createdAt
                          ).toLocaleTimeString()}`}</span>
                        </div>
                        <div className="font-semibold col-4 ">
                          <div className="">{item.note}</div>
                        </div>
                      </div>
                    </>
                  );
                })
              )}
            </CardWithTitle>
          </div>
        </div>
        <div className="flex justify-content-end pt-2">
          <div className="flex  mr-2 mt-3 ">
            <div className="mx-2">
              <Buttons
                onClick={onClickActiveNotes}
                label="Add"
                icon={"pi pi-plus-circle"}
                className="btn-dark border-none"
              ></Buttons>
            </div>
            <div>
              <Buttons
                label="Print"
                icon={"pi pi-print"}
                className="bg-yellow  border-none"
              ></Buttons>
            </div>
            <div className="mx-2">
              <Buttons
                label="Save"
                onClick={createEmployee}
                className="btn-dark  border-none"
              ></Buttons>
            </div>
            <div>
              <Buttons
                label="Cancel"
                className="btn-grey border-none"
              ></Buttons>
            </div>
          </div>
        </div>
      </>
    );
  };

  const AddNotes = () => {
    return (
      <>
        <div>
          <CardWithTitle title="Notes">
            <div className=" p-3">
              <label className="text-xs font-semibold text-dark-gray px-2 gap-2">
                Notes
              </label>
              <div className="pt-2">
                <InputTextarea
                  style={{ width: "100%", height: "250px" }}
                  value={noteValue.note}
                  onChange={(e) =>
                    setNoteValue({
                      note: e.target.value,
                      createdBy: localStorage.getItem("fullName"),
                      createdAt: Date.now(),
                    })
                  }
                />
              </div>
              {errors.note && (
                      <p className="text-red-600 text-xs mt-1">{errors.note}</p>
                    )}
            </div>
          </CardWithTitle>
        </div>
        <div className="flex justify-content-end pt-2">
          <div className="flex  mr-2 mt-3 ">
            <div className="mx-2">
              <Buttons
                onClick={addNote}
                label="Done"
                className="btn-dark  border-none"
              ></Buttons>
            </div>
            <div>
              <Buttons
                label="Cancel"
                className="btn-grey border-none"
              ></Buttons>
            </div>
          </div>
        </div>
      </>
    );
  };

  return (
    <>
      {showNotes ? AddNotes() : showTableNotes()}
      <div>
        <RecentCheckIn data={checkInData} />
      </div>
    </>
  );
};

export default Notes;
