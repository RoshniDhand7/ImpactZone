import React from "react";
import CardWithTitle from "../../../../components/cards/cardWithTitle/cardWithTitle";
import DropDown from "../../../../components/dropdown/dropdown";
import { InputTextarea } from "primereact/inputtextarea";
import { useState } from "react";
import Buttons from "../../../../components/buttons/button";
import { useSelector } from "react-redux";

const EventNotifications = ({
  addEventData,
  handleChange,
  setActiveIndex,
  submit,
}) => {
  const choiceTypeOptions = useSelector((state) => state.staticData.choiceType);
  let atLeastOption = [];
  for (let i = 0; i <= 24; i++) {
    let obj = { label: `${i} Hours`, value: `${i} Hours` };
    atLeastOption.push(obj);
  }
  const [value, setValue] = useState("");
  return (
    <>
      <div>
        <p className="text-xl font-semibold my-3 text-900">Add Event Setups</p>
        <div className="">
          <CardWithTitle title="Event Reminders">
            <div className="p-3">
              <div className="flex">
                <div className="col-3">
                  <DropDown
                    title="Sent Event Notifications"
                    value={addEventData.eventReminder.sendEventNotification}
                    options={choiceTypeOptions}
                    optionLabel="label"
                    onChange={handleChange}
                    name="sendEventNotification|eventReminder"
                  ></DropDown>
                </div>
                <div className="col-3">
                  <DropDown
                    title="Time before event to send text"
                    value={addEventData.eventReminder.timeBeforeEventToSendText}
                    options={atLeastOption}
                    optionLabel="label"
                    onChange={handleChange}
                    name="timeBeforeEventToSendText|eventReminder"
                  ></DropDown>
                </div>
              </div>
              <div className="col">
                <div className=" flex flex-column gap-2 ">
                  <label
                    HtmlFor=""
                    className="text-xs text-dark-gray   font-semibold "
                  >
                    {`Message (${addEventData?.eventReminder?.message?.length}/100)`}
                  </label>

                  <InputTextarea
                    // value={value}
                    value={addEventData.eventReminder.message}
                    onChange={
                      addEventData?.eventReminder?.message?.length == 100
                        ? null
                        : handleChange
                    }
                    name="message|eventReminder"
                    // onChange={(e) => setValue(e.target.value)}
                    style={{ width: "100%", height: "155px" }}
                  />
                </div>
              </div>
            </div>
          </CardWithTitle>
        </div>
        <div className="mt-3">
          <CardWithTitle title="Cancellation">
            <div className="p-3">
              <div className="col-3">
                <DropDown
                  title="Send cancel link with text"
                  value={addEventData.eventReminder.sendCancelLink}
                  options={choiceTypeOptions}
                  optionLabel="label"
                  onChange={handleChange}
                  name="sendCancelLink|eventReminder"
                ></DropDown>
              </div>
            </div>
          </CardWithTitle>
        </div>
      </div>
      <div className=" m-2  flex justify-content-end">
        <div className="mt-3 mx-4">
          <Buttons
            label="Save"
            onClick={() => submit()}
            className="btn-dark mx-3   border-none"
          ></Buttons>
        </div>
        <div className="mt-3">
          <Buttons
            label="Cancel"
            className="btn-grey   border-none"
            onClick={() => setActiveIndex(3)}
          ></Buttons>
        </div>
      </div>
    </>
  );
};

export default EventNotifications;
